from django.db import models
from django.contrib.auth.models import User

# need username and password
class Account(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,)

    
    def __init__(self, username, account_number, current_amount):
        self.name = username
        self.no = account_number
        self.balance = current_amount

    def get_balance(self):
        return self._balance

    def dump(self):
        s = '%s, %s, balance: %s' % \
            (self.client, self.no, self.balance)
    
